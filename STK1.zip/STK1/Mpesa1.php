<?php
//Maina Variable test i.e Create variables from each $_POST.
//*******************************************************************************************************
// Check if a person has clicked on submit.
if(isset($_POST['btnSubmit'])) { 
    
	// Check if a person has filled every form.
if(empty($_POST['txtPhone']) || empty($_POST['txtAmount']))
	 {echo "You have to fill in everything in the form."; // Display the error message. Mtu lazima aweke kitu!
				exit; // Stop the code to prevent the code running after redirecting.
		}
	/*
	// Create variables from each $_POST.
	$name = $_POST['txtAmount'];
	$regno = $_POST['txtPhone'];
	*/
	
//**************************************************************************************************
//get token from mpesa
// let do some payments
$BusinessShortCode = "174379"; //BusinessShortCode = "174379"  //4117539
    $LipaNaMpesaPasskey = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";//cl5gGFaNy3gvEGmHQTgx5nwV2Ndr7CR3    bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919
    $TransactionType  = "CustomerPayBillOnline";//customertillonline
   // $Amount  = "1";*/
   // $PartyA =  "254721726515";
   //************************************************
	$Amount = $_POST['txtAmount'];
	$PartyA = $_POST['txtPhone']; //8/8/23 254708374149
	//$PartyA ="600979";
	//***********************************************
    $PartyB =  "174379"; //PartyB =  "174379"
   // $PhoneNumber   = "254721726515";
   //*****************************************
   $PhoneNumber= $_POST['txtPhone'];
   //*****************************************
   
 //*****************************************************
//Go back to HOME PAGE
header('location: thanks.xhtml');
//*******************************************************
}
    $CallBackURL  = "127.0.0.1/stk1/confirmation.php";
	//$CallBackURL  = "https://modcom.co.ke/job/confirmation.php";
    $AccountReference = "INNOVATION"; // "Modcom Account"
    $TransactionDesc = "Pay for Internet 1GB";
    $Remarks = "Good day";


   $stkPushSimulation=STKPushSimulation($BusinessShortCode, $LipaNaMpesaPasskey, $TransactionType, $Amount, $PartyA, $PartyB, $PhoneNumber, $CallBackURL, $AccountReference, $TransactionDesc, $Remarks);

function generateAccessToken()
        {
            /* $consumer_key="3CApXqvJP7UFp72XdcKOLRlA6dpxO6ST";
            $consumer_secret="IXhr3NUITE5dmRnc"; */
			$consumer_key="QpJ0sjioO7UE9d7JAyQTtr9msjDOgo82"; // old = 3CApXqvJP7UFp72XdcKOLRlA6dpxO6ST
            $consumer_secret="GJwZKrPHrMBHUHSI"; //old= IXhr3NUITE5dmRnc
			$credentials = base64_encode($consumer_key.":".$consumer_secret);
            $url = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials";
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array("Authorization: Basic ".$credentials));
            curl_setopt($curl, CURLOPT_HEADER,false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $curl_response = curl_exec($curl);
            $access_token=json_decode($curl_response);
            return $access_token->access_token;
        }
        // call token function --GENERATE token per tran
         $token = generateAccessToken();
        echo "$token";

//PUSH STK CODE
function STKPushSimulation($BusinessShortCode, $LipaNaMpesaPasskey, $TransactionType, $Amount, $PartyA, $PartyB, $PhoneNumber, $CallBackURL, $AccountReference, $TransactionDesc, $Remark){
        
    
        $environment = 'sandbox';//not live
        
        if( $environment =="live"){
            $url = 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
             $token = generateAccessToken();
          
        }elseif ($environment=="sandbox"){
            $url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
            $token = generateAccessToken();
            
        }

        else{
            return json_encode(["Message"=>"invalid application status"]);
        }


        $timestamp='10'.date(    "ymdhis"); //timestamp='20'
        $password=base64_encode($BusinessShortCode.$LipaNaMpesaPasskey.$timestamp);

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.$token));


        $curl_post_data = array(
            'BusinessShortCode' => $BusinessShortCode,
            'Password' => $password,
            'Timestamp' => $timestamp,
            'TransactionType' => $TransactionType,
            'Amount' => $Amount,
            'PartyA' => $PartyA,
            'PartyB' => $PartyB,
            'PhoneNumber' => $PhoneNumber,
            'CallBackURL' => $CallBackURL,
            'AccountReference' => $AccountReference,
            'TransactionDesc' => $TransactionType
        );

        $data_string = json_encode($curl_post_data);

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl, CURLOPT_HEADER, false);
        $curl_response=curl_exec($curl);
        return $curl_response;
    }
?>
